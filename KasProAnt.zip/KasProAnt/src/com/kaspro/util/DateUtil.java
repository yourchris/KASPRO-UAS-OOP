package com.kaspro.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

/**
 * Utilitas format tanggal & waktu (bahasa Indonesia).
 */
public class DateUtil {

    private static final Locale ID = Locale.forLanguageTag("id-ID");
    private static final DateTimeFormatter F_TGL =
            DateTimeFormatter.ofPattern("d MMM yyyy", ID);
    private static final DateTimeFormatter F_TGL_WAKTU =
            DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm", ID);

    public static String format(LocalDate tgl) {
        return tgl == null ? "-" : tgl.format(F_TGL);
    }

    public static String format(LocalDateTime waktu) {
        return waktu == null ? "-" : waktu.format(F_TGL_WAKTU);
    }

    /** Selisih hari dari hari ini ke tanggal target (positif = masih akan datang). */
    public static long sisaHari(LocalDate target) {
        if (target == null) return 0;
        return ChronoUnit.DAYS.between(LocalDate.now(), target);
    }

    /** Label ramah untuk jatuh tempo. */
    public static String labelJatuhTempo(LocalDate target) {
        if (target == null) return "-";
        long hari = sisaHari(target);
        if (hari < 0)  return "Terlambat " + Math.abs(hari) + " hari";
        if (hari == 0) return "Jatuh tempo hari ini";
        if (hari == 1) return "Jatuh tempo besok";
        return "Jatuh tempo " + hari + " hari lagi";
    }
}
