package com.kaspro.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * Utilitas hashing password.
 * <p>Menghasilkan SHA-256 dalam format hex huruf kecil sehingga
 * cocok dengan hasil fungsi {@code SHA2(teks, 256)} milik MySQL,
 * yang dipakai pada seeder akun default di skrip DDL.</p>
 */
public class PasswordUtil {

    public static String hash(String teks) {
        if (teks == null) teks = "";
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(teks.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) {
                sb.append(Character.forDigit((b >> 4) & 0xF, 16));
                sb.append(Character.forDigit(b & 0xF, 16));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("Gagal hashing password", e);
        }
    }

    /** Membandingkan password mentah dengan hash tersimpan. */
    public static boolean cocok(String mentah, String hashTersimpan) {
        if (hashTersimpan == null) return false;
        return hash(mentah).equalsIgnoreCase(hashTersimpan);
    }
}
