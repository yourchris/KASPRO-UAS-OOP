package com.kaspro.util;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Utilitas upload & baca gambar bukti pembayaran.
 */
public class FileUtil {

    private static final String UPLOAD_DIR = "uploads/";
    private static final long   MAX_UKURAN = 5L * 1024 * 1024; // 5MB

    /** Hasil pemilihan file: path tersimpan + nama file asli. */
    public static class HasilUpload {
        public final String path;
        public final String namaFile;
        public HasilUpload(String path, String namaFile) {
            this.path = path;
            this.namaFile = namaFile;
        }
    }

    /**
     * Menampilkan dialog pilih file lalu menyalinnya ke folder {@code uploads/}.
     * @return objek {@link HasilUpload}, atau {@code null} bila dibatalkan/gagal.
     */
    public static HasilUpload pilihDanSimpan(Component parent) throws IOException {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Pilih Bukti Pembayaran");
        chooser.setFileFilter(new FileNameExtensionFilter(
            "Gambar (JPG, PNG)", "jpg", "jpeg", "png"));
        chooser.setAcceptAllFileFilterUsed(false);

        if (chooser.showOpenDialog(parent) != JFileChooser.APPROVE_OPTION) {
            return null; // Pengguna batal
        }

        File file = chooser.getSelectedFile();

        if (file.length() > MAX_UKURAN) {
            JOptionPane.showMessageDialog(parent,
                "Ukuran file terlalu besar (maks. 5MB).",
                "File Terlalu Besar", JOptionPane.WARNING_MESSAGE);
            return null;
        }

        Path dirPath = Paths.get(UPLOAD_DIR);
        if (!Files.exists(dirPath)) Files.createDirectories(dirPath);

        String timestamp = LocalDateTime.now()
            .format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String ext      = getEkstension(file.getName());
        String namaFile = "bukti_" + timestamp + "." + ext;
        Path tujuan     = dirPath.resolve(namaFile);

        Files.copy(file.toPath(), tujuan, StandardCopyOption.REPLACE_EXISTING);
        return new HasilUpload(tujuan.toString(), file.getName());
    }

    /** Membaca gambar dari path dan mengembalikannya sebagai ImageIcon terskala. */
    public static ImageIcon bacaGambar(String path, int lebar, int tinggi) {
        if (path == null || path.isEmpty()) return null;
        try {
            File file = new File(path);
            if (!file.exists()) return null;
            ImageIcon icon = new ImageIcon(file.getAbsolutePath());
            if (icon.getIconWidth() <= 0) return null;
            Image img = icon.getImage().getScaledInstance(
                lebar, tinggi, Image.SCALE_SMOOTH);
            return new ImageIcon(img);
        } catch (Exception e) {
            System.err.println("Gagal baca gambar: " + path);
            return null;
        }
    }

    private static String getEkstension(String namaFile) {
        int dot = namaFile.lastIndexOf('.');
        return (dot > 0) ? namaFile.substring(dot + 1).toLowerCase() : "jpg";
    }
}
