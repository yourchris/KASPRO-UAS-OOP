package com.kaspro.util;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Utilitas format mata uang Rupiah.
 */
public class CurrencyUtil {

    private static final Locale LOCALE_ID = Locale.forLanguageTag("id-ID");

    public static String format(BigDecimal nominal) {
        if (nominal == null) return "Rp 0";
        NumberFormat nf = NumberFormat.getCurrencyInstance(LOCALE_ID);
        nf.setMaximumFractionDigits(0);
        return nf.format(nominal);
    }

    public static String format(long nominal) {
        return format(BigDecimal.valueOf(nominal));
    }

    /** Mengubah teks ("Rp 50.000", "50000", dst) menjadi BigDecimal. */
    public static BigDecimal parse(String teks) {
        try {
            if (teks == null) return BigDecimal.ZERO;
            String bersih = teks.replaceAll("[^0-9]", "");
            if (bersih.isEmpty()) return BigDecimal.ZERO;
            return new BigDecimal(bersih);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }
}
