package com.kaspro.view;

import com.kaspro.controller.AuthController;
import com.kaspro.controller.VerifikasiController;
import com.kaspro.dao.PembayaranDAO;
import com.kaspro.model.Pembayaran;
import com.kaspro.util.CurrencyUtil;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import java.awt.Dimension;
import java.awt.Image;
import java.io.File;
import java.util.List;

/**
 * Form verifikasi pembayaran (bendahara): setujui / tolak pembayaran masuk.
 */
public class FrmVerifikasi extends javax.swing.JFrame {

    private final PembayaranDAO pembayaranDAO = new PembayaranDAO();
    private final VerifikasiController ctrl = new VerifikasiController();

    private List<Pembayaran> data;

    public FrmVerifikasi() {
        initComponents();
        setLocationRelativeTo(null);
        tblPending.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) tampilkanDetail();
        });
        muat();
    }

    private void muat() {
        DefaultTableModel m = new DefaultTableModel(
            new Object[]{"#", "Anggota", "Periode", "Nominal", "Metode", "Dikirim"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        data = pembayaranDAO.getPending();
        int no = 1;
        for (Pembayaran p : data) {
            m.addRow(new Object[]{
                no++, p.getNamaAnggota(), p.getNamaPeriode(),
                CurrencyUtil.format(p.getNominalBayar()),
                p.getMetodeLabel(), p.getDikirimFormatted()
            });
        }
        tblPending.setModel(m);
        lblDetail.setText(" ");
    }

    private void tampilkanDetail() {
        int row = tblPending.getSelectedRow();
        if (row < 0 || data == null || row >= data.size()) return;
        Pembayaran p = data.get(row);
        String ref = p.getNoReferensi() != null && !p.getNoReferensi().isEmpty()
                ? p.getNoReferensi() : "-";
        String catatan = p.getCatatanAnggota() != null && !p.getCatatanAnggota().isEmpty()
                ? p.getCatatanAnggota() : "-";
        lblDetail.setText("<html><b>" + p.getNamaAnggota() + "</b> (" + p.getNoAnggota() + ")"
                + " &nbsp;|&nbsp; " + p.getNamaPeriode()
                + "<br>Nominal: " + CurrencyUtil.format(p.getNominalBayar())
                + " &nbsp;|&nbsp; Metode: " + p.getMetodeLabel()
                + " (" + (p.getNamaBank() != null ? p.getNamaBank() : "-") + ")"
                + "<br>Referensi: " + ref + " &nbsp;|&nbsp; Catatan: " + catatan + "</html>");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblJudul = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPending = new javax.swing.JTable();
        lblDetail = new javax.swing.JLabel();
        btnLihatBukti = new javax.swing.JButton();
        lblAlasan = new javax.swing.JLabel();
        txtAlasan = new javax.swing.JTextField();
        btnSetujui = new javax.swing.JButton();
        btnTolak = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("KasPro - Verifikasi Pembayaran");

        lblJudul.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblJudul.setText("Verifikasi Pembayaran");

        jScrollPane1.setViewportView(tblPending);

        lblDetail.setText(" ");
        lblDetail.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        btnLihatBukti.setText("Lihat Bukti");
        btnLihatBukti.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLihatBuktiActionPerformed(evt);
            }
        });

        lblAlasan.setText("Alasan penolakan (wajib bila menolak)");

        btnSetujui.setText("Setujui");
        btnSetujui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSetujuiActionPerformed(evt);
            }
        });

        btnTolak.setText("Tolak");
        btnTolak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTolakActionPerformed(evt);
            }
        });

        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblJudul)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 560, Short.MAX_VALUE)
                    .addComponent(lblDetail, javax.swing.GroupLayout.DEFAULT_SIZE, 560, Short.MAX_VALUE)
                    .addComponent(btnLihatBukti)
                    .addComponent(lblAlasan)
                    .addComponent(txtAlasan)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSetujui)
                        .addGap(10, 10, 10)
                        .addComponent(btnTolak)
                        .addGap(10, 10, 10)
                        .addComponent(btnRefresh)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblJudul)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addGap(12, 12, 12)
                .addComponent(lblDetail, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(btnLihatBukti)
                .addGap(14, 14, 14)
                .addComponent(lblAlasan)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtAlasan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSetujui)
                    .addComponent(btnTolak)
                    .addComponent(btnRefresh))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLihatBuktiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLihatBuktiActionPerformed
        int row = tblPending.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih baris pembayaran terlebih dahulu.");
            return;
        }
        String path = data.get(row).getPathBukti();
        if (path == null || !new File(path).exists()) {
            JOptionPane.showMessageDialog(this, "File bukti tidak ditemukan.");
            return;
        }
        ImageIcon full = new ImageIcon(path);
        int w = full.getIconWidth(), h = full.getIconHeight();
        int maxW = 800, maxH = 600;
        if (w > maxW || h > maxH) {
            double skala = Math.min((double) maxW / w, (double) maxH / h);
            Image img = full.getImage().getScaledInstance(
                (int) (w * skala), (int) (h * skala), Image.SCALE_SMOOTH);
            full = new ImageIcon(img);
        }
        JLabel isi = new JLabel(full);
        isi.setHorizontalAlignment(SwingConstants.CENTER);
        JScrollPane sc = new JScrollPane(isi);
        sc.setPreferredSize(new Dimension(
            Math.min(full.getIconWidth() + 40, 840),
            Math.min(full.getIconHeight() + 40, 640)));
        JOptionPane.showMessageDialog(this, sc, "Bukti Pembayaran", JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_btnLihatBuktiActionPerformed

    private void btnSetujuiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSetujuiActionPerformed
        int row = tblPending.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih baris pembayaran terlebih dahulu.");
            return;
        }
        Pembayaran p = data.get(row);
        int ok = JOptionPane.showConfirmDialog(this,
            "Setujui pembayaran dari " + p.getNamaAnggota() + "?",
            "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (ok != JOptionPane.YES_OPTION) return;
        int idBendahara = AuthController.getCurrentUser().getId();
        boolean berhasil = ctrl.setujui(p.getId(), p.getIdTagihan(), p.getIdAnggota(), idBendahara);
        if (berhasil) {
            JOptionPane.showMessageDialog(this, "Pembayaran disetujui.");
            muat();
        } else {
            JOptionPane.showMessageDialog(this, "Gagal memproses persetujuan.",
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnSetujuiActionPerformed

    private void btnTolakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTolakActionPerformed
        int row = tblPending.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih baris pembayaran terlebih dahulu.");
            return;
        }
        String alasan = txtAlasan.getText().trim();
        if (alasan.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Isi alasan penolakan terlebih dahulu.");
            txtAlasan.requestFocus();
            return;
        }
        Pembayaran p = data.get(row);
        int ok = JOptionPane.showConfirmDialog(this,
            "Tolak pembayaran dari " + p.getNamaAnggota() + "?",
            "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (ok != JOptionPane.YES_OPTION) return;
        int idBendahara = AuthController.getCurrentUser().getId();
        boolean berhasil = ctrl.tolak(p.getId(), p.getIdTagihan(), p.getIdAnggota(), idBendahara, alasan);
        if (berhasil) {
            JOptionPane.showMessageDialog(this, "Pembayaran ditolak.");
            txtAlasan.setText("");
            muat();
        } else {
            JOptionPane.showMessageDialog(this, "Gagal memproses penolakan.",
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnTolakActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        muat();
    }//GEN-LAST:event_btnRefreshActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLihatBukti;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnSetujui;
    private javax.swing.JButton btnTolak;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblAlasan;
    private javax.swing.JLabel lblDetail;
    private javax.swing.JLabel lblJudul;
    private javax.swing.JTable tblPending;
    private javax.swing.JTextField txtAlasan;
    // End of variables declaration//GEN-END:variables
}
