package com.kaspro.view;

import com.kaspro.controller.AuthController;
import com.kaspro.controller.TagihanController;
import com.kaspro.dao.PeriodeDAO;
import com.kaspro.dao.TagihanDAO;
import com.kaspro.model.PeriodeKas;
import com.kaspro.util.CurrencyUtil;
import com.kaspro.util.DateUtil;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Form kelola periode kas (bendahara): lihat daftar + buat periode baru + tutup.
 */
public class FrmPeriode extends javax.swing.JFrame {

    private final PeriodeDAO periodeDAO = new PeriodeDAO();
    private final TagihanDAO tagihanDAO = new TagihanDAO();
    private final TagihanController ctrl = new TagihanController();

    private List<PeriodeKas> data;

    public FrmPeriode() {
        initComponents();
        setLocationRelativeTo(null);
        txtMulai.setText(LocalDate.now().toString());
        txtTempo.setText(LocalDate.now().plusDays(7).toString());
        muat();
    }

    private void muat() {
        DefaultTableModel m = new DefaultTableModel(
            new Object[]{"Nama Periode", "Nominal", "Mulai", "Jatuh Tempo", "Status", "Lunas/Total"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        data = periodeDAO.getAll();
        for (PeriodeKas p : data) {
            int[] s = tagihanDAO.getSummaryByPeriode(p.getId());
            m.addRow(new Object[]{
                p.getNamaPeriode(),
                CurrencyUtil.format(p.getNominal()),
                DateUtil.format(p.getTanggalMulai()),
                DateUtil.format(p.getTanggalJatuhTempo()),
                p.isAktif() ? "Aktif" : "Tutup",
                s[1] + " / " + s[0]
            });
        }
        tblPeriode.setModel(m);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblJudul = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPeriode = new javax.swing.JTable();
        lblForm = new javax.swing.JLabel();
        lblNama = new javax.swing.JLabel();
        txtNama = new javax.swing.JTextField();
        lblNominal = new javax.swing.JLabel();
        txtNominal = new javax.swing.JTextField();
        lblMulai = new javax.swing.JLabel();
        txtMulai = new javax.swing.JTextField();
        lblTempo = new javax.swing.JLabel();
        txtTempo = new javax.swing.JTextField();
        lblDesk = new javax.swing.JLabel();
        txtDesk = new javax.swing.JTextField();
        btnBuat = new javax.swing.JButton();
        btnTutup = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("KasPro - Periode Kas");

        lblJudul.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblJudul.setText("Periode Kas");

        jScrollPane1.setViewportView(tblPeriode);

        lblForm.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblForm.setText("Buat Periode Baru");

        lblNama.setText("Nama Periode");

        lblNominal.setText("Nominal");

        lblMulai.setText("Tgl Mulai (YYYY-MM-DD)");

        lblTempo.setText("Jatuh Tempo (YYYY-MM-DD)");

        lblDesk.setText("Deskripsi");

        btnBuat.setText("Buat Periode");
        btnBuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuatActionPerformed(evt);
            }
        });

        btnTutup.setText("Tutup Terpilih");
        btnTutup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTutupActionPerformed(evt);
            }
        });

        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblJudul)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 540, Short.MAX_VALUE)
                    .addComponent(lblForm)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblNama)
                            .addComponent(lblNominal)
                            .addComponent(lblMulai)
                            .addComponent(lblTempo)
                            .addComponent(lblDesk))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNama)
                            .addComponent(txtNominal)
                            .addComponent(txtMulai)
                            .addComponent(txtTempo)
                            .addComponent(txtDesk)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnBuat)
                        .addGap(10, 10, 10)
                        .addComponent(btnTutup)
                        .addGap(10, 10, 10)
                        .addComponent(btnRefresh)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblJudul)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addGap(16, 16, 16)
                .addComponent(lblForm)
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNama)
                    .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNominal)
                    .addComponent(txtNominal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMulai)
                    .addComponent(txtMulai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTempo)
                    .addComponent(txtTempo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDesk)
                    .addComponent(txtDesk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBuat)
                    .addComponent(btnTutup)
                    .addComponent(btnRefresh))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuatActionPerformed
        if (txtNama.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama periode wajib diisi.");
            return;
        }
        BigDecimal nominal = CurrencyUtil.parse(txtNominal.getText());
        if (nominal.signum() <= 0) {
            JOptionPane.showMessageDialog(this, "Nominal harus lebih dari 0.");
            return;
        }
        LocalDate mulai, tempo;
        try {
            mulai = LocalDate.parse(txtMulai.getText().trim());
            tempo = LocalDate.parse(txtTempo.getText().trim());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Format tanggal salah. Gunakan YYYY-MM-DD.");
            return;
        }
        if (tempo.isBefore(mulai)) {
            JOptionPane.showMessageDialog(this, "Jatuh tempo tidak boleh sebelum tanggal mulai.");
            return;
        }

        PeriodeKas p = new PeriodeKas();
        p.setNamaPeriode(txtNama.getText().trim());
        p.setNominal(nominal);
        p.setTanggalMulai(mulai);
        p.setTanggalJatuhTempo(tempo);
        p.setDeskripsi(txtDesk.getText().trim());
        p.setDibuatOleh(AuthController.getCurrentUser().getId());

        TagihanController.Hasil hasil = ctrl.buatPeriode(p);
        JOptionPane.showMessageDialog(this, hasil.pesan,
            hasil.sukses ? "Berhasil" : "Gagal",
            hasil.sukses ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.WARNING_MESSAGE);
        if (hasil.sukses) {
            txtNama.setText("");
            txtNominal.setText("");
            txtDesk.setText("");
            muat();
        }
    }//GEN-LAST:event_btnBuatActionPerformed

    private void btnTutupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTutupActionPerformed
        int row = tblPeriode.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih periode pada tabel terlebih dahulu.");
            return;
        }
        PeriodeKas p = data.get(row);
        int ok = JOptionPane.showConfirmDialog(this,
            "Tutup periode \"" + p.getNamaPeriode() + "\"?",
            "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION && ctrl.tutupPeriode(p.getId())) {
            muat();
        }
    }//GEN-LAST:event_btnTutupActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        muat();
    }//GEN-LAST:event_btnRefreshActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuat;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnTutup;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblDesk;
    private javax.swing.JLabel lblForm;
    private javax.swing.JLabel lblJudul;
    private javax.swing.JLabel lblMulai;
    private javax.swing.JLabel lblNama;
    private javax.swing.JLabel lblNominal;
    private javax.swing.JLabel lblTempo;
    private javax.swing.JTable tblPeriode;
    private javax.swing.JTextField txtDesk;
    private javax.swing.JTextField txtMulai;
    private javax.swing.JTextField txtNama;
    private javax.swing.JTextField txtNominal;
    private javax.swing.JTextField txtTempo;
    // End of variables declaration//GEN-END:variables
}
