package com.kaspro.view;

import com.kaspro.controller.AuthController;
import com.kaspro.controller.PembayaranController;
import com.kaspro.dao.TagihanDAO;
import com.kaspro.model.Pembayaran;
import com.kaspro.model.Tagihan;
import com.kaspro.util.CurrencyUtil;
import com.kaspro.util.FileUtil;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.List;

/**
 * Form pembayaran kas untuk anggota: lihat tagihan + kirim pembayaran + bukti.
 */
public class FrmBayar extends javax.swing.JFrame {

    private static final String[] KODE_METODE =
            {"transfer_bank", "dompet_digital", "tunai", "lainnya"};

    private final TagihanDAO tagihanDAO = new TagihanDAO();
    private final PembayaranController ctrl = new PembayaranController();

    private List<Tagihan> data;
    private Tagihan terpilih;
    private String buktiPath;
    private String buktiNama;

    public FrmBayar() {
        initComponents();
        setLocationRelativeTo(null);
        lblWelcome.setText("Halo, " + AuthController.getCurrentUser().getNamaLengkap());
        tblTagihan.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) pilihTagihan();
        });
        muat();
    }

    private void muat() {
        DefaultTableModel m = new DefaultTableModel(
            new Object[]{"Periode", "Nominal", "Status"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        data = tagihanDAO.getByAnggota(AuthController.getCurrentUser().getId());
        for (Tagihan t : data) {
            m.addRow(new Object[]{
                t.getNamaPeriode(), CurrencyUtil.format(t.getNominal()), t.getLabelStatus()
            });
        }
        tblTagihan.setModel(m);
        terpilih = null;
        buktiPath = null;
        buktiNama = null;
        lblFile.setText("Belum ada file dipilih.");
        lblTagihanInfo.setText("Pilih tagihan pada tabel untuk dibayar.");
    }

    private void pilihTagihan() {
        int row = tblTagihan.getSelectedRow();
        if (row < 0 || data == null || row >= data.size()) return;
        Tagihan t = data.get(row);
        if (!t.bisaDibayar()) {
            terpilih = null;
            lblTagihanInfo.setText("Tagihan ini berstatus \"" + t.getLabelStatus()
                    + "\" dan tidak bisa dibayar sekarang.");
            return;
        }
        terpilih = t;
        lblTagihanInfo.setText("<html>Membayar: <b>" + t.getNamaPeriode()
                + "</b> sebesar <b>" + CurrencyUtil.format(t.getNominal()) + "</b></html>");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblJudul = new javax.swing.JLabel();
        lblWelcome = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblTagihan = new javax.swing.JTable();
        lblForm = new javax.swing.JLabel();
        lblTagihanInfo = new javax.swing.JLabel();
        lblMetode = new javax.swing.JLabel();
        cmbMetode = new javax.swing.JComboBox<>();
        lblBank = new javax.swing.JLabel();
        txtBank = new javax.swing.JTextField();
        lblRef = new javax.swing.JLabel();
        txtRef = new javax.swing.JTextField();
        lblCatatan = new javax.swing.JLabel();
        txtCatatan = new javax.swing.JTextField();
        btnPilihBukti = new javax.swing.JButton();
        lblFile = new javax.swing.JLabel();
        btnKirim = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("KasPro - Bayar Kas");

        lblJudul.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblJudul.setText("Tagihan Kas Saya");

        lblWelcome.setText("Halo, Anggota");

        jScrollPane1.setViewportView(tblTagihan);

        lblForm.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblForm.setText("Form Pembayaran");

        lblTagihanInfo.setText("Pilih tagihan pada tabel untuk dibayar.");

        lblMetode.setText("Metode");

        cmbMetode.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Transfer Bank", "Dompet Digital", "Tunai", "Lainnya" }));

        lblBank.setText("Bank / E-Wallet");

        lblRef.setText("No. Referensi");

        lblCatatan.setText("Catatan");

        btnPilihBukti.setText("Pilih Bukti...");
        btnPilihBukti.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPilihBuktiActionPerformed(evt);
            }
        });

        lblFile.setText("Belum ada file dipilih.");

        btnKirim.setText("Kirim Pembayaran");
        btnKirim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKirimActionPerformed(evt);
            }
        });

        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        btnLogout.setText("Keluar");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblJudul)
                    .addComponent(lblWelcome)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 560, Short.MAX_VALUE)
                    .addComponent(lblForm)
                    .addComponent(lblTagihanInfo, javax.swing.GroupLayout.DEFAULT_SIZE, 560, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblMetode)
                            .addComponent(lblBank)
                            .addComponent(lblRef)
                            .addComponent(lblCatatan))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbMetode, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtBank)
                            .addComponent(txtRef)
                            .addComponent(txtCatatan)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnPilihBukti)
                        .addGap(12, 12, 12)
                        .addComponent(lblFile))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnKirim)
                        .addGap(10, 10, 10)
                        .addComponent(btnRefresh)
                        .addGap(10, 10, 10)
                        .addComponent(btnLogout)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblJudul)
                .addGap(2, 2, 2)
                .addComponent(lblWelcome)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                .addGap(14, 14, 14)
                .addComponent(lblForm)
                .addGap(6, 6, 6)
                .addComponent(lblTagihanInfo)
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMetode)
                    .addComponent(cmbMetode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBank)
                    .addComponent(txtBank, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRef)
                    .addComponent(txtRef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCatatan)
                    .addComponent(txtCatatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPilihBukti)
                    .addComponent(lblFile))
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnKirim)
                    .addComponent(btnRefresh)
                    .addComponent(btnLogout))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPilihBuktiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPilihBuktiActionPerformed
        try {
            FileUtil.HasilUpload hasil = FileUtil.pilihDanSimpan(this);
            if (hasil != null) {
                buktiPath = hasil.path;
                buktiNama = hasil.namaFile;
                lblFile.setText(hasil.namaFile);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Gagal menyalin file bukti: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnPilihBuktiActionPerformed

    private void btnKirimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKirimActionPerformed
        if (terpilih == null) {
            JOptionPane.showMessageDialog(this, "Pilih tagihan yang bisa dibayar terlebih dahulu.");
            return;
        }
        if (buktiPath == null) {
            JOptionPane.showMessageDialog(this, "Lampirkan bukti pembayaran terlebih dahulu.");
            return;
        }

        Pembayaran p = new Pembayaran();
        p.setIdTagihan(terpilih.getId());
        p.setIdAnggota(AuthController.getCurrentUser().getId());
        p.setNominalBayar(terpilih.getNominal());
        p.setMetode(KODE_METODE[cmbMetode.getSelectedIndex()]);
        p.setNamaBank(txtBank.getText().trim());
        p.setNoReferensi(txtRef.getText().trim());
        p.setPathBukti(buktiPath);
        p.setNamaFileBukti(buktiNama);
        p.setCatatanAnggota(txtCatatan.getText().trim());

        boolean ok = ctrl.kirimPembayaran(p, AuthController.getCurrentUser().getNamaLengkap());
        if (ok) {
            JOptionPane.showMessageDialog(this,
                "Pembayaran terkirim dan menunggu verifikasi bendahara.");
            txtBank.setText("");
            txtRef.setText("");
            txtCatatan.setText("");
            muat();
        } else {
            JOptionPane.showMessageDialog(this, "Gagal mengirim pembayaran.",
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnKirimActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        muat();
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        AuthController.logout();
        new FrmLogin().setVisible(true);
        dispose();
    }//GEN-LAST:event_btnLogoutActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnKirim;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnPilihBukti;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JComboBox<String> cmbMetode;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBank;
    private javax.swing.JLabel lblCatatan;
    private javax.swing.JLabel lblFile;
    private javax.swing.JLabel lblForm;
    private javax.swing.JLabel lblJudul;
    private javax.swing.JLabel lblMetode;
    private javax.swing.JLabel lblRef;
    private javax.swing.JLabel lblTagihanInfo;
    private javax.swing.JLabel lblWelcome;
    private javax.swing.JTable tblTagihan;
    private javax.swing.JTextField txtBank;
    private javax.swing.JTextField txtCatatan;
    private javax.swing.JTextField txtRef;
    // End of variables declaration//GEN-END:variables
}
