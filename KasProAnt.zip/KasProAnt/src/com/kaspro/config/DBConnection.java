package com.kaspro.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

/**
 * Pengelola koneksi tunggal (singleton) ke database MySQL.
 * Konfigurasi dibaca dari resource {@code config.properties}.
 */
public class DBConnection {

    private static Connection instance = null;

    private static final String HOST, PORT, DB, USER, PASS;

    static {
        Properties p = new Properties();
        try (InputStream in = DBConnection.class
                .getClassLoader().getResourceAsStream("config.properties")) {
            if (in == null) {
                throw new RuntimeException("config.properties tidak ditemukan di classpath");
            }
            p.load(in);
        } catch (Exception e) {
            throw new RuntimeException("Gagal membaca config.properties", e);
        }
        HOST = p.getProperty("db.host", "localhost");
        PORT = p.getProperty("db.port", "3306");
        DB   = p.getProperty("db.name", "db_kas");
        USER = p.getProperty("db.user", "root");
        PASS = p.getProperty("db.password", "");
    }

    private DBConnection() {}

    public static Connection getConnection() throws SQLException {
        if (instance == null || instance.isClosed()) {
            String url = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB
                       + "?useSSL=false&serverTimezone=Asia/Jakarta"
                       + "&allowPublicKeyRetrieval=true";
            instance = DriverManager.getConnection(url, USER, PASS);
        }
        return instance;
    }

    public static void close() {
        try {
            if (instance != null && !instance.isClosed()) {
                instance.close();
                instance = null;
            }
        } catch (SQLException e) {
            System.err.println("Error menutup koneksi: " + e.getMessage());
        }
    }
}
