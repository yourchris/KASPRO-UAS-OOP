package com.kaspro;

import com.kaspro.view.FrmLogin;

import javax.swing.UIManager;

/**
 * Titik masuk aplikasi KasPro (versi Java Swing JFrame Form / Ant).
 */
public class Main {

    public static void main(String[] args) {
        // Look and Feel Nimbus (bawaan JDK) bila tersedia
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // abaikan, pakai L&F default
        }

        java.awt.EventQueue.invokeLater(() -> new FrmLogin().setVisible(true));
    }
}
