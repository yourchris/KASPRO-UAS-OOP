package com.kaspro.dao;

import com.kaspro.config.DBConnection;
import com.kaspro.model.User;
import com.kaspro.util.PasswordUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    /** Validasi login. Mengembalikan User bila cocok & aktif, selain itu null. */
    public User login(String username, String passwordMentah) {
        String sql = "SELECT * FROM users WHERE username = ? AND aktif = 1";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String hashDb = rs.getString("password");
                if (PasswordUtil.cocok(passwordMentah, hashDb)) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("login error: " + e.getMessage());
        }
        return null;
    }

    public User getById(int id) {
        String sql = "SELECT * FROM users WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("getById error: " + e.getMessage());
        }
        return null;
    }

    /** Semua user dengan role tertentu. */
    public List<User> getByRole(String role) {
        String sql = "SELECT * FROM users WHERE role = ? ORDER BY nama_lengkap";
        List<User> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, role);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("getByRole error: " + e.getMessage());
        }
        return list;
    }

    /** Seluruh anggota (role = anggota), aktif maupun tidak. */
    public List<User> getAllAnggota() {
        return getByRole("anggota");
    }

    public int countAnggotaAktif() {
        String sql = "SELECT COUNT(*) FROM users WHERE role = 'anggota' AND aktif = 1";
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("countAnggotaAktif error: " + e.getMessage());
        }
        return 0;
    }

    /** Simpan user baru. Password di-hash di sini. */
    public boolean simpan(User u, String passwordMentah) {
        String sql = """
            INSERT INTO users
              (username, password, nama_lengkap, email, no_hp, role, no_anggota, aktif)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, u.getUsername());
            ps.setString(2, PasswordUtil.hash(passwordMentah));
            ps.setString(3, u.getNamaLengkap());
            ps.setString(4, u.getEmail());
            ps.setString(5, u.getNoHp());
            ps.setString(6, u.getRole());
            ps.setString(7, u.getNoAnggota());
            ps.setInt(8, u.isAktif() ? 1 : 0);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("simpan user error: " + e.getMessage());
        }
        return false;
    }

    /** Aktif/nonaktifkan anggota. */
    public boolean setAktif(int id, boolean aktif) {
        String sql = "UPDATE users SET aktif = ? WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, aktif ? 1 : 0);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("setAktif error: " + e.getMessage());
        }
        return false;
    }

    /** Ubah password (password baru mentah, di-hash di sini). */
    public boolean ubahPassword(int id, String passwordBaru) {
        String sql = "UPDATE users SET password = ? WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, PasswordUtil.hash(passwordBaru));
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("ubahPassword error: " + e.getMessage());
        }
        return false;
    }

    /** Cek ketersediaan username. */
    public boolean usernameTersedia(String username) {
        String sql = "SELECT 1 FROM users WHERE username = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            return !ps.executeQuery().next();
        } catch (SQLException e) {
            System.err.println("usernameTersedia error: " + e.getMessage());
        }
        return false;
    }

    private User mapRow(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getInt("id"));
        u.setUsername(rs.getString("username"));
        u.setPassword(rs.getString("password"));
        u.setNamaLengkap(rs.getString("nama_lengkap"));
        u.setEmail(rs.getString("email"));
        u.setNoHp(rs.getString("no_hp"));
        u.setRole(rs.getString("role"));
        u.setNoAnggota(rs.getString("no_anggota"));
        u.setAktif(rs.getInt("aktif") == 1);
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) u.setCreatedAt(ts.toLocalDateTime());
        return u;
    }
}
