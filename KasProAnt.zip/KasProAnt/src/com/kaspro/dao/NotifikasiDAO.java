package com.kaspro.dao;

import com.kaspro.config.DBConnection;
import com.kaspro.model.Notifikasi;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotifikasiDAO {

    /** Kirim satu notifikasi ke satu penerima. */
    public boolean kirim(int idPenerima, String pesan, String tipe, int idReferensi) {
        String sql = """
            INSERT INTO notifikasi (id_penerima, pesan, tipe, id_referensi)
            VALUES (?, ?, ?, ?)
            """;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idPenerima);
            ps.setString(2, pesan);
            ps.setString(3, tipe);
            if (idReferensi > 0) ps.setInt(4, idReferensi);
            else ps.setNull(4, Types.INTEGER);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("kirim notifikasi error: " + e.getMessage());
        }
        return false;
    }

    /** Broadcast notifikasi ke seluruh user dengan role tertentu. */
    public int kirimKeRole(String role, String pesan, String tipe, int idReferensi) {
        String sql = """
            INSERT INTO notifikasi (id_penerima, pesan, tipe, id_referensi)
            SELECT id, ?, ?, ? FROM users WHERE role = ? AND aktif = 1
            """;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, pesan);
            ps.setString(2, tipe);
            if (idReferensi > 0) ps.setInt(3, idReferensi);
            else ps.setNull(3, Types.INTEGER);
            ps.setString(4, role);
            return ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("kirimKeRole error: " + e.getMessage());
        }
        return 0;
    }

    public List<Notifikasi> getByPenerima(int idPenerima) {
        String sql = "SELECT * FROM notifikasi WHERE id_penerima = ? ORDER BY created_at DESC LIMIT 50";
        List<Notifikasi> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idPenerima);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("getByPenerima error: " + e.getMessage());
        }
        return list;
    }

    public int countBelumDibaca(int idPenerima) {
        String sql = "SELECT COUNT(*) FROM notifikasi WHERE id_penerima = ? AND sudah_dibaca = 0";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idPenerima);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("countBelumDibaca error: " + e.getMessage());
        }
        return 0;
    }

    public boolean tandaiSemuaDibaca(int idPenerima) {
        String sql = "UPDATE notifikasi SET sudah_dibaca = 1 WHERE id_penerima = ? AND sudah_dibaca = 0";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idPenerima);
            return ps.executeUpdate() >= 0;
        } catch (SQLException e) {
            System.err.println("tandaiSemuaDibaca error: " + e.getMessage());
        }
        return false;
    }

    private Notifikasi mapRow(ResultSet rs) throws SQLException {
        Notifikasi n = new Notifikasi();
        n.setId(rs.getInt("id"));
        n.setIdPenerima(rs.getInt("id_penerima"));
        n.setPesan(rs.getString("pesan"));
        n.setTipe(rs.getString("tipe"));
        n.setIdReferensi(rs.getInt("id_referensi"));
        n.setSudahDibaca(rs.getInt("sudah_dibaca") == 1);
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) n.setCreatedAt(ts.toLocalDateTime());
        return n;
    }
}
