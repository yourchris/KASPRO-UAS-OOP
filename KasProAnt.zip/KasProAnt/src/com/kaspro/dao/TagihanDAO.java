package com.kaspro.dao;

import com.kaspro.config.DBConnection;
import com.kaspro.model.Tagihan;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TagihanDAO {

    /** Semua tagihan milik anggota tertentu. */
    public List<Tagihan> getByAnggota(int idAnggota) {
        String sql = """
            SELECT t.*, p.nama_periode, p.tanggal_jatuh_tempo, u.nama_lengkap, u.no_anggota
            FROM tagihan t
            JOIN periode_kas p ON t.id_periode = p.id
            JOIN users u ON t.id_anggota = u.id
            WHERE t.id_anggota = ?
            ORDER BY p.tanggal_mulai DESC
            """;
        return queryList(sql, idAnggota);
    }

    /** Tagihan aktif (belum bayar / ditolak) milik anggota pada periode yang masih aktif. */
    public List<Tagihan> getTagihanAktif(int idAnggota) {
        String sql = """
            SELECT t.*, p.nama_periode, p.tanggal_jatuh_tempo,
                   u.nama_lengkap, u.no_anggota
            FROM tagihan t
            JOIN periode_kas p ON t.id_periode = p.id
            JOIN users u ON t.id_anggota = u.id
            WHERE t.id_anggota = ?
              AND t.status IN ('belum_bayar', 'ditolak')
              AND p.status = 'aktif'
            ORDER BY p.tanggal_jatuh_tempo ASC
            """;
        return queryList(sql, idAnggota);
    }

    /** Semua tagihan dalam satu periode (untuk bendahara). */
    public List<Tagihan> getByPeriode(int idPeriode) {
        String sql = """
            SELECT t.*, p.nama_periode, p.tanggal_jatuh_tempo, u.nama_lengkap, u.no_anggota
            FROM tagihan t
            JOIN periode_kas p ON t.id_periode = p.id
            JOIN users u ON t.id_anggota = u.id
            WHERE t.id_periode = ?
            ORDER BY u.nama_lengkap ASC
            """;
        return queryList(sql, idPeriode);
    }

    public Tagihan getById(int id) {
        String sql = """
            SELECT t.*, p.nama_periode, p.tanggal_jatuh_tempo, u.nama_lengkap, u.no_anggota
            FROM tagihan t
            JOIN periode_kas p ON t.id_periode = p.id
            JOIN users u ON t.id_anggota = u.id
            WHERE t.id = ?
            """;
        List<Tagihan> list = queryList(sql, id);
        return list.isEmpty() ? null : list.get(0);
    }

    /** Buat tagihan untuk semua anggota aktif pada periode baru. */
    public int buatTagihanMassal(int idPeriode, BigDecimal nominal) {
        String sqlAnggota = "SELECT id FROM users WHERE role = 'anggota' AND aktif = 1";
        String sqlInsert  = "INSERT IGNORE INTO tagihan (id_periode, id_anggota, nominal) VALUES (?, ?, ?)";
        int count = 0;

        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sqlAnggota);
             PreparedStatement ps = con.prepareStatement(sqlInsert)) {

            while (rs.next()) {
                ps.setInt(1, idPeriode);
                ps.setInt(2, rs.getInt("id"));
                ps.setBigDecimal(3, nominal);
                count += ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.err.println("buatTagihanMassal error: " + e.getMessage());
        }
        return count;
    }

    /** Update status tagihan. */
    public boolean updateStatus(int idTagihan, String status, String catatan) {
        String sql = "UPDATE tagihan SET status = ?, catatan = ?, updated_at = NOW() WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, catatan);
            ps.setInt(3, idTagihan);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("updateStatus error: " + e.getMessage());
        }
        return false;
    }

    /**
     * Ringkasan tagihan per periode.
     * @return array {@code [total, lunas, menunggu, belum, ditolak]}.
     */
    public int[] getSummaryByPeriode(int idPeriode) {
        String sql = """
            SELECT COUNT(*) total,
                   SUM(status='lunas') lunas,
                   SUM(status='menunggu_verifikasi') menunggu,
                   SUM(status='belum_bayar') belum,
                   SUM(status='ditolak') ditolak
            FROM tagihan WHERE id_periode = ?
            """;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idPeriode);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new int[]{
                    rs.getInt("total"), rs.getInt("lunas"),
                    rs.getInt("menunggu"), rs.getInt("belum"),
                    rs.getInt("ditolak")
                };
            }
        } catch (SQLException e) {
            System.err.println("getSummary error: " + e.getMessage());
        }
        return new int[5];
    }

    private List<Tagihan> queryList(String sql, int param) {
        List<Tagihan> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, param);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("queryList error: " + e.getMessage());
        }
        return list;
    }

    private Tagihan mapRow(ResultSet rs) throws SQLException {
        Tagihan t = new Tagihan();
        t.setId(rs.getInt("id"));
        t.setIdPeriode(rs.getInt("id_periode"));
        t.setIdAnggota(rs.getInt("id_anggota"));
        t.setNominal(rs.getBigDecimal("nominal"));
        t.setStatus(rs.getString("status"));
        t.setCatatan(rs.getString("catatan"));
        t.setNamaPeriode(rs.getString("nama_periode"));
        t.setNamaAnggota(rs.getString("nama_lengkap"));
        t.setNoAnggota(rs.getString("no_anggota"));
        // Kolom opsional (tidak selalu ada pada tiap query)
        try {
            Date jt = rs.getDate("tanggal_jatuh_tempo");
            if (jt != null) t.setTanggalJatuhTempo(jt.toLocalDate());
        } catch (SQLException ignored) {}
        try {
            Timestamp c = rs.getTimestamp("created_at");
            if (c != null) t.setCreatedAt(c.toLocalDateTime());
        } catch (SQLException ignored) {}
        try {
            Timestamp u = rs.getTimestamp("updated_at");
            if (u != null) t.setUpdatedAt(u.toLocalDateTime());
        } catch (SQLException ignored) {}
        return t;
    }
}
