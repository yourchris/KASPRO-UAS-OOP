package com.kaspro.dao;

import com.kaspro.config.DBConnection;
import com.kaspro.model.PeriodeKas;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PeriodeDAO {

    /** Simpan periode baru. Mengembalikan id yang dihasilkan, atau -1 bila gagal. */
    public int simpan(PeriodeKas p) {
        String sql = """
            INSERT INTO periode_kas
              (nama_periode, nominal, tanggal_mulai, tanggal_jatuh_tempo, deskripsi, dibuat_oleh)
            VALUES (?, ?, ?, ?, ?, ?)
            """;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, p.getNamaPeriode());
            ps.setBigDecimal(2, p.getNominal());
            ps.setDate(3, Date.valueOf(p.getTanggalMulai()));
            ps.setDate(4, Date.valueOf(p.getTanggalJatuhTempo()));
            ps.setString(5, p.getDeskripsi());
            if (p.getDibuatOleh() > 0) ps.setInt(6, p.getDibuatOleh());
            else ps.setNull(6, Types.INTEGER);

            if (ps.executeUpdate() > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) return keys.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.err.println("simpan periode error: " + e.getMessage());
        }
        return -1;
    }

    public List<PeriodeKas> getAll() {
        String sql = "SELECT * FROM periode_kas ORDER BY tanggal_mulai DESC";
        return query(sql);
    }

    public List<PeriodeKas> getAktif() {
        String sql = "SELECT * FROM periode_kas WHERE status = 'aktif' ORDER BY tanggal_mulai DESC";
        return query(sql);
    }

    public PeriodeKas getById(int id) {
        String sql = "SELECT * FROM periode_kas WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("getById periode error: " + e.getMessage());
        }
        return null;
    }

    public boolean tutupPeriode(int id) {
        String sql = "UPDATE periode_kas SET status = 'tutup' WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("tutupPeriode error: " + e.getMessage());
        }
        return false;
    }

    /** Membuat baris rekap awal untuk sebuah periode. */
    public boolean buatRekapAwal(int idPeriode, java.math.BigDecimal totalTagihan, int jumlahAnggota) {
        String sql = """
            INSERT INTO rekap_kas
              (id_periode, total_tagihan, total_terkumpul, jumlah_lunas, jumlah_belum)
            VALUES (?, ?, 0, 0, ?)
            """;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idPeriode);
            ps.setBigDecimal(2, totalTagihan);
            ps.setInt(3, jumlahAnggota);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("buatRekapAwal error: " + e.getMessage());
        }
        return false;
    }

    private List<PeriodeKas> query(String sql) {
        List<PeriodeKas> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("query periode error: " + e.getMessage());
        }
        return list;
    }

    private PeriodeKas mapRow(ResultSet rs) throws SQLException {
        PeriodeKas p = new PeriodeKas();
        p.setId(rs.getInt("id"));
        p.setNamaPeriode(rs.getString("nama_periode"));
        p.setNominal(rs.getBigDecimal("nominal"));
        Date tm = rs.getDate("tanggal_mulai");
        if (tm != null) p.setTanggalMulai(tm.toLocalDate());
        Date tj = rs.getDate("tanggal_jatuh_tempo");
        if (tj != null) p.setTanggalJatuhTempo(tj.toLocalDate());
        p.setDeskripsi(rs.getString("deskripsi"));
        p.setStatus(rs.getString("status"));
        p.setDibuatOleh(rs.getInt("dibuat_oleh"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) p.setCreatedAt(ts.toLocalDateTime());
        return p;
    }
}
