package com.kaspro.dao;

import com.kaspro.config.DBConnection;
import com.kaspro.model.Pembayaran;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PembayaranDAO {

    /** Simpan pembayaran baru dari anggota (status default 'menunggu'). */
    public boolean simpan(Pembayaran p) {
        String sql = """
            INSERT INTO pembayaran
              (id_tagihan, id_anggota, nominal_bayar, metode, nama_bank,
               no_referensi, path_bukti, nama_file_bukti, catatan_anggota)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
              id_anggota      = VALUES(id_anggota),
              nominal_bayar   = VALUES(nominal_bayar),
              metode          = VALUES(metode),
              nama_bank       = VALUES(nama_bank),
              no_referensi    = VALUES(no_referensi),
              path_bukti      = VALUES(path_bukti),
              nama_file_bukti = VALUES(nama_file_bukti),
              catatan_anggota = VALUES(catatan_anggota),
              status          = 'menunggu',
              catatan_penolakan = NULL,
              diperiksa_oleh  = NULL,
              diverifikasi_at = NULL,
              dikirim_at      = NOW()
            """;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, p.getIdTagihan());
            ps.setInt(2, p.getIdAnggota());
            ps.setBigDecimal(3, p.getNominalBayar());
            ps.setString(4, p.getMetode());
            ps.setString(5, p.getNamaBank());
            ps.setString(6, p.getNoReferensi());
            ps.setString(7, p.getPathBukti());
            ps.setString(8, p.getNamaFileBukti());
            ps.setString(9, p.getCatatanAnggota());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("simpanPembayaran error: " + e.getMessage());
        }
        return false;
    }

    /** Semua pembayaran berstatus 'menunggu' (untuk bendahara). */
    public List<Pembayaran> getPending() {
        String sql = """
            SELECT pb.*, t.id_periode, p.nama_periode,
                   u.nama_lengkap, u.no_anggota
            FROM pembayaran pb
            JOIN tagihan t ON pb.id_tagihan = t.id
            JOIN periode_kas p ON t.id_periode = p.id
            JOIN users u ON pb.id_anggota = u.id
            WHERE pb.status = 'menunggu'
            ORDER BY pb.dikirim_at ASC
            """;
        List<Pembayaran> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("getPending error: " + e.getMessage());
        }
        return list;
    }

    /** Riwayat pembayaran milik anggota tertentu. */
    public List<Pembayaran> getByAnggota(int idAnggota) {
        String sql = """
            SELECT pb.*, t.id_periode, p.nama_periode,
                   u.nama_lengkap, u.no_anggota
            FROM pembayaran pb
            JOIN tagihan t ON pb.id_tagihan = t.id
            JOIN periode_kas p ON t.id_periode = p.id
            JOIN users u ON pb.id_anggota = u.id
            WHERE pb.id_anggota = ?
            ORDER BY pb.dikirim_at DESC
            """;
        List<Pembayaran> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idAnggota);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("getByAnggota pembayaran error: " + e.getMessage());
        }
        return list;
    }

    /** Riwayat pembayaran yang sudah diverifikasi (disetujui/ditolak) untuk bendahara. */
    public List<Pembayaran> getRiwayatVerifikasi() {
        String sql = """
            SELECT pb.*, t.id_periode, p.nama_periode,
                   u.nama_lengkap, u.no_anggota
            FROM pembayaran pb
            JOIN tagihan t ON pb.id_tagihan = t.id
            JOIN periode_kas p ON t.id_periode = p.id
            JOIN users u ON pb.id_anggota = u.id
            WHERE pb.status IN ('disetujui', 'ditolak')
            ORDER BY pb.diverifikasi_at DESC
            """;
        List<Pembayaran> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            System.err.println("getRiwayatVerifikasi error: " + e.getMessage());
        }
        return list;
    }

    /** Pembayaran terakhir untuk satu tagihan. */
    public Pembayaran getByTagihan(int idTagihan) {
        String sql = "SELECT * FROM pembayaran WHERE id_tagihan = ? ORDER BY dikirim_at DESC LIMIT 1";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idTagihan);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            System.err.println("getByTagihan error: " + e.getMessage());
        }
        return null;
    }

    /** Verifikasi: setujui atau tolak pembayaran. */
    public boolean verifikasi(int idPembayaran, String status,
                               String catatan, int idBendahara) {
        String sql = """
            UPDATE pembayaran
            SET status = ?, catatan_penolakan = ?,
                diperiksa_oleh = ?, diverifikasi_at = NOW()
            WHERE id = ?
            """;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, catatan);
            ps.setInt(3, idBendahara);
            ps.setInt(4, idPembayaran);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("verifikasi error: " + e.getMessage());
        }
        return false;
    }

    private Pembayaran mapRow(ResultSet rs) throws SQLException {
        Pembayaran p = new Pembayaran();
        p.setId(rs.getInt("id"));
        p.setIdTagihan(rs.getInt("id_tagihan"));
        p.setIdAnggota(rs.getInt("id_anggota"));
        p.setNominalBayar(rs.getBigDecimal("nominal_bayar"));
        p.setMetode(rs.getString("metode"));
        p.setNamaBank(rs.getString("nama_bank"));
        p.setNoReferensi(rs.getString("no_referensi"));
        p.setPathBukti(rs.getString("path_bukti"));
        p.setNamaFileBukti(rs.getString("nama_file_bukti"));
        p.setCatatanAnggota(rs.getString("catatan_anggota"));
        p.setStatus(rs.getString("status"));
        p.setCatatanPenolakan(rs.getString("catatan_penolakan"));
        Timestamp dk = rs.getTimestamp("dikirim_at");
        if (dk != null) p.setDikirimAt(dk.toLocalDateTime());
        Timestamp dv = rs.getTimestamp("diverifikasi_at");
        if (dv != null) p.setDiverifikasiAt(dv.toLocalDateTime());
        // Kolom hasil join (tidak selalu ada)
        try { p.setNamaPeriode(rs.getString("nama_periode")); } catch (SQLException ignored) {}
        try { p.setNamaAnggota(rs.getString("nama_lengkap")); } catch (SQLException ignored) {}
        try { p.setNoAnggota(rs.getString("no_anggota")); }     catch (SQLException ignored) {}
        return p;
    }
}
