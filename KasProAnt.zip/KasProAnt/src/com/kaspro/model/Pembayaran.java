package com.kaspro.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Model pembayaran: bukti bayar yang diunggah anggota.
 */
public class Pembayaran {

    private int           id;
    private int           idTagihan;
    private int           idAnggota;
    private BigDecimal    nominalBayar;
    private String        metode;          // transfer_bank | dompet_digital | tunai | lainnya
    private String        namaBank;
    private String        noReferensi;
    private String        pathBukti;
    private String        namaFileBukti;
    private String        catatanAnggota;
    private String        status = "menunggu";   // menunggu | disetujui | ditolak
    private int           diperiksaOleh;
    private String        catatanPenolakan;
    private LocalDateTime dikirimAt;
    private LocalDateTime diverifikasiAt;

    // Field hasil join
    private String namaPeriode;
    private String namaAnggota;
    private String noAnggota;

    public Pembayaran() {}

    // ── Getters & Setters ───────────────────────────────────────
    public int        getId()                   { return id; }
    public void       setId(int id)             { this.id = id; }

    public int        getIdTagihan()            { return idTagihan; }
    public void       setIdTagihan(int v)       { this.idTagihan = v; }

    public int        getIdAnggota()            { return idAnggota; }
    public void       setIdAnggota(int v)       { this.idAnggota = v; }

    public BigDecimal getNominalBayar()         { return nominalBayar; }
    public void       setNominalBayar(BigDecimal v) { this.nominalBayar = v; }

    public String     getMetode()               { return metode; }
    public void       setMetode(String v)       { this.metode = v; }

    public String     getNamaBank()             { return namaBank; }
    public void       setNamaBank(String v)     { this.namaBank = v; }

    public String     getNoReferensi()          { return noReferensi; }
    public void       setNoReferensi(String v)  { this.noReferensi = v; }

    public String     getPathBukti()            { return pathBukti; }
    public void       setPathBukti(String v)    { this.pathBukti = v; }

    public String     getNamaFileBukti()        { return namaFileBukti; }
    public void       setNamaFileBukti(String v){ this.namaFileBukti = v; }

    public String     getCatatanAnggota()       { return catatanAnggota; }
    public void       setCatatanAnggota(String v){ this.catatanAnggota = v; }

    public String     getStatus()               { return status; }
    public void       setStatus(String v)       { this.status = v; }

    public int        getDiperiksaOleh()        { return diperiksaOleh; }
    public void       setDiperiksaOleh(int v)   { this.diperiksaOleh = v; }

    public String     getCatatanPenolakan()     { return catatanPenolakan; }
    public void       setCatatanPenolakan(String v) { this.catatanPenolakan = v; }

    public LocalDateTime getDikirimAt()         { return dikirimAt; }
    public void          setDikirimAt(LocalDateTime v) { this.dikirimAt = v; }

    public LocalDateTime getDiverifikasiAt()    { return diverifikasiAt; }
    public void          setDiverifikasiAt(LocalDateTime v) { this.diverifikasiAt = v; }

    public String     getNamaPeriode()          { return namaPeriode; }
    public void       setNamaPeriode(String v)  { this.namaPeriode = v; }

    public String     getNamaAnggota()          { return namaAnggota; }
    public void       setNamaAnggota(String v)  { this.namaAnggota = v; }

    public String     getNoAnggota()            { return noAnggota; }
    public void       setNoAnggota(String v)    { this.noAnggota = v; }

    // ── Helper ──────────────────────────────────────────────────
    public String getMetodeLabel() {
        if (metode == null) return "-";
        String label = switch (metode) {
            case "transfer_bank"  -> "Transfer Bank";
            case "dompet_digital" -> "Dompet Digital";
            case "tunai"          -> "Tunai";
            case "lainnya"        -> "Lainnya";
            default               -> metode;
        };
        if (namaBank != null && !namaBank.isBlank()) {
            label += " (" + namaBank + ")";
        }
        return label;
    }

    public String getDikirimFormatted() {
        if (dikirimAt == null) return "-";
        return dikirimAt.format(DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm"));
    }
}
