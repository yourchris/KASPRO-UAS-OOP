package com.kaspro.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Model tagihan: satu tagihan per anggota per periode.
 */
public class Tagihan {

    private int           id;
    private int           idPeriode;
    private int           idAnggota;
    private BigDecimal    nominal;
    private String        status;          // belum_bayar | menunggu_verifikasi | lunas | ditolak
    private String        catatan;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Field hasil join (tidak disimpan langsung di tabel tagihan)
    private String     namaPeriode;
    private String     namaAnggota;
    private String     noAnggota;
    private LocalDate  tanggalJatuhTempo;
    private BigDecimal nominalPembayaran;

    public Tagihan() {}

    // ── Getters & Setters ──────────────────────────────────────
    public int         getId()                  { return id; }
    public void        setId(int id)            { this.id = id; }

    public int         getIdPeriode()           { return idPeriode; }
    public void        setIdPeriode(int v)      { this.idPeriode = v; }

    public int         getIdAnggota()           { return idAnggota; }
    public void        setIdAnggota(int v)      { this.idAnggota = v; }

    public BigDecimal  getNominal()             { return nominal; }
    public void        setNominal(BigDecimal v) { this.nominal = v; }

    public String      getStatus()              { return status; }
    public void        setStatus(String v)      { this.status = v; }

    public String      getCatatan()             { return catatan; }
    public void        setCatatan(String v)     { this.catatan = v; }

    public LocalDateTime getCreatedAt()         { return createdAt; }
    public void          setCreatedAt(LocalDateTime v) { this.createdAt = v; }

    public LocalDateTime getUpdatedAt()         { return updatedAt; }
    public void          setUpdatedAt(LocalDateTime v) { this.updatedAt = v; }

    public String      getNamaPeriode()         { return namaPeriode; }
    public void        setNamaPeriode(String v) { this.namaPeriode = v; }

    public String      getNamaAnggota()         { return namaAnggota; }
    public void        setNamaAnggota(String v) { this.namaAnggota = v; }

    public String      getNoAnggota()           { return noAnggota; }
    public void        setNoAnggota(String v)   { this.noAnggota = v; }

    public LocalDate   getTanggalJatuhTempo()   { return tanggalJatuhTempo; }
    public void        setTanggalJatuhTempo(LocalDate v) { this.tanggalJatuhTempo = v; }

    public BigDecimal  getNominalPembayaran()       { return nominalPembayaran; }
    public void        setNominalPembayaran(BigDecimal v) { this.nominalPembayaran = v; }

    // Helper: label status yang ramah dibaca
    public String getLabelStatus() {
        if (status == null) return "-";
        return switch (status) {
            case "belum_bayar"          -> "Belum Bayar";
            case "menunggu_verifikasi"  -> "Menunggu Verifikasi";
            case "lunas"                -> "Lunas";
            case "ditolak"              -> "Ditolak";
            default                     -> status;
        };
    }

    // Helper: warna badge status
    public java.awt.Color getWarnaStatus() {
        if (status == null) return new java.awt.Color(107, 114, 128);
        return switch (status) {
            case "lunas"                -> new java.awt.Color(22, 163, 74);    // hijau
            case "menunggu_verifikasi"  -> new java.awt.Color(202, 138, 4);    // kuning gelap
            case "ditolak"              -> new java.awt.Color(220, 38, 38);    // merah
            default                     -> new java.awt.Color(107, 114, 128);  // abu
        };
    }

    /** True bila tagihan masih bisa dibayar (belum bayar / ditolak). */
    public boolean bisaDibayar() {
        return "belum_bayar".equals(status) || "ditolak".equals(status);
    }
}
