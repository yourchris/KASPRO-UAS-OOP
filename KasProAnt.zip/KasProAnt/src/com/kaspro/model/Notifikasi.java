package com.kaspro.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Model notifikasi in-app.
 */
public class Notifikasi {

    private int           id;
    private int           idPenerima;
    private String        pesan;
    private String        tipe;            // pembayaran_masuk | disetujui | ditolak | tagihan_baru | pengingat
    private int           idReferensi;
    private boolean       sudahDibaca;
    private LocalDateTime createdAt;

    public Notifikasi() {}

    public Notifikasi(int idPenerima, String pesan, String tipe, int idReferensi) {
        this.idPenerima  = idPenerima;
        this.pesan       = pesan;
        this.tipe        = tipe;
        this.idReferensi = idReferensi;
    }

    // ── Getters & Setters ───────────────────────────────────────
    public int     getId()                  { return id; }
    public void    setId(int id)            { this.id = id; }

    public int     getIdPenerima()          { return idPenerima; }
    public void    setIdPenerima(int v)     { this.idPenerima = v; }

    public String  getPesan()               { return pesan; }
    public void    setPesan(String v)       { this.pesan = v; }

    public String  getTipe()                { return tipe; }
    public void    setTipe(String v)        { this.tipe = v; }

    public int     getIdReferensi()         { return idReferensi; }
    public void    setIdReferensi(int v)    { this.idReferensi = v; }

    public boolean isSudahDibaca()          { return sudahDibaca; }
    public void    setSudahDibaca(boolean v){ this.sudahDibaca = v; }

    public LocalDateTime getCreatedAt()     { return createdAt; }
    public void          setCreatedAt(LocalDateTime v) { this.createdAt = v; }

    public String getWaktuFormatted() {
        if (createdAt == null) return "";
        return createdAt.format(DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm"));
    }
}
