package com.kaspro.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Model periode kas (siklus tagihan: bulanan, semester, dll).
 */
public class PeriodeKas {

    private int           id;
    private String        namaPeriode;
    private BigDecimal    nominal;
    private LocalDate     tanggalMulai;
    private LocalDate     tanggalJatuhTempo;
    private String        deskripsi;
    private String        status = "aktif";   // aktif | tutup
    private int           dibuatOleh;
    private LocalDateTime createdAt;

    public PeriodeKas() {}

    // ── Getters & Setters ───────────────────────────────────────
    public int        getId()                  { return id; }
    public void       setId(int id)            { this.id = id; }

    public String     getNamaPeriode()         { return namaPeriode; }
    public void       setNamaPeriode(String v) { this.namaPeriode = v; }

    public BigDecimal getNominal()             { return nominal; }
    public void       setNominal(BigDecimal v) { this.nominal = v; }

    public LocalDate  getTanggalMulai()        { return tanggalMulai; }
    public void       setTanggalMulai(LocalDate v) { this.tanggalMulai = v; }

    public LocalDate  getTanggalJatuhTempo()   { return tanggalJatuhTempo; }
    public void       setTanggalJatuhTempo(LocalDate v) { this.tanggalJatuhTempo = v; }

    public String     getDeskripsi()           { return deskripsi; }
    public void       setDeskripsi(String v)   { this.deskripsi = v; }

    public String     getStatus()              { return status; }
    public void       setStatus(String v)      { this.status = v; }

    public int        getDibuatOleh()          { return dibuatOleh; }
    public void       setDibuatOleh(int v)     { this.dibuatOleh = v; }

    public LocalDateTime getCreatedAt()        { return createdAt; }
    public void          setCreatedAt(LocalDateTime v) { this.createdAt = v; }

    public boolean isAktif() { return "aktif".equalsIgnoreCase(status); }

    @Override
    public String toString() { return namaPeriode; }
}
