package com.kaspro.model;

import java.time.LocalDateTime;

/**
 * Model untuk akun pengguna (admin, bendahara, anggota).
 */
public class User {

    private int           id;
    private String        username;
    private String        password;      // SHA-256 hex
    private String        namaLengkap;
    private String        email;
    private String        noHp;
    private String        role;          // admin | bendahara | anggota
    private String        noAnggota;
    private boolean       aktif = true;
    private LocalDateTime createdAt;

    public User() {}

    public User(String username, String namaLengkap, String role) {
        this.username    = username;
        this.namaLengkap = namaLengkap;
        this.role        = role;
    }

    // ── Getters & Setters ───────────────────────────────────────
    public int    getId()                 { return id; }
    public void   setId(int id)           { this.id = id; }

    public String getUsername()           { return username; }
    public void   setUsername(String v)   { this.username = v; }

    public String getPassword()           { return password; }
    public void   setPassword(String v)   { this.password = v; }

    public String getNamaLengkap()        { return namaLengkap; }
    public void   setNamaLengkap(String v){ this.namaLengkap = v; }

    public String getEmail()              { return email; }
    public void   setEmail(String v)      { this.email = v; }

    public String getNoHp()               { return noHp; }
    public void   setNoHp(String v)       { this.noHp = v; }

    public String getRole()               { return role; }
    public void   setRole(String v)       { this.role = v; }

    public String getNoAnggota()          { return noAnggota; }
    public void   setNoAnggota(String v)  { this.noAnggota = v; }

    public boolean isAktif()              { return aktif; }
    public void   setAktif(boolean v)     { this.aktif = v; }

    public LocalDateTime getCreatedAt()       { return createdAt; }
    public void          setCreatedAt(LocalDateTime v) { this.createdAt = v; }

    // ── Helper ──────────────────────────────────────────────────
    public boolean isBendahara() { return "bendahara".equalsIgnoreCase(role); }
    public boolean isAdmin()     { return "admin".equalsIgnoreCase(role); }
    public boolean isAnggota()   { return "anggota".equalsIgnoreCase(role); }

    public String getRoleLabel() {
        if (role == null) return "-";
        return switch (role) {
            case "admin"     -> "Administrator";
            case "bendahara" -> "Bendahara";
            case "anggota"   -> "Anggota";
            default          -> role;
        };
    }

    @Override
    public String toString() {
        return namaLengkap + (noAnggota != null ? " (" + noAnggota + ")" : "");
    }
}
