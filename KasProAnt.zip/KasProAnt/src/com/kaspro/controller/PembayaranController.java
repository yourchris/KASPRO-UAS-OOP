package com.kaspro.controller;

import com.kaspro.dao.NotifikasiDAO;
import com.kaspro.dao.PembayaranDAO;
import com.kaspro.dao.TagihanDAO;
import com.kaspro.dao.UserDAO;
import com.kaspro.model.Pembayaran;
import com.kaspro.model.User;

import java.util.List;

/**
 * Logika pengiriman pembayaran oleh anggota.
 */
public class PembayaranController {

    private final PembayaranDAO pembayaranDAO = new PembayaranDAO();
    private final TagihanDAO    tagihanDAO    = new TagihanDAO();
    private final UserDAO       userDAO       = new UserDAO();
    private final NotifikasiDAO notifDAO      = new NotifikasiDAO();

    /**
     * Mengirim pembayaran:
     * <ol>
     *   <li>Simpan/perbarui data pembayaran (status 'menunggu').</li>
     *   <li>Ubah status tagihan menjadi 'menunggu_verifikasi'.</li>
     *   <li>Kirim notifikasi ke seluruh bendahara.</li>
     * </ol>
     */
    public boolean kirimPembayaran(Pembayaran p, String namaAnggota) {
        boolean okSimpan = pembayaranDAO.simpan(p);
        if (!okSimpan) return false;

        boolean okTagihan = tagihanDAO.updateStatus(
            p.getIdTagihan(), "menunggu_verifikasi", null);

        // Notifikasi ke semua bendahara
        List<User> bendaharaList = userDAO.getByRole("bendahara");
        for (User b : bendaharaList) {
            notifDAO.kirim(b.getId(),
                "Pembayaran baru dari " + namaAnggota + " menunggu verifikasi.",
                "pembayaran_masuk", p.getIdTagihan());
        }

        return okTagihan;
    }
}
