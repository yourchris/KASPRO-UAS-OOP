package com.kaspro.controller;

import com.kaspro.dao.NotifikasiDAO;
import com.kaspro.dao.PembayaranDAO;
import com.kaspro.dao.TagihanDAO;

/**
 * Logika verifikasi pembayaran (setujui / tolak) oleh bendahara.
 */
public class VerifikasiController {

    private final PembayaranDAO pembayaranDAO = new PembayaranDAO();
    private final TagihanDAO    tagihanDAO    = new TagihanDAO();
    private final NotifikasiDAO notifDAO      = new NotifikasiDAO();

    /**
     * Setujui pembayaran.
     * Mengubah status pembayaran → 'disetujui' dan tagihan → 'lunas'.
     * Rekap kas diperbarui otomatis oleh trigger MySQL.
     */
    public boolean setujui(int idPembayaran, int idTagihan,
                           int idAnggota, int idBendahara) {
        boolean okPembayaran = pembayaranDAO.verifikasi(
            idPembayaran, "disetujui", null, idBendahara);

        boolean okTagihan = tagihanDAO.updateStatus(
            idTagihan, "lunas", null);

        if (okPembayaran && okTagihan) {
            notifDAO.kirim(idAnggota,
                "Pembayaran kas Anda telah disetujui. Terima kasih!",
                "disetujui", idPembayaran);
        }
        return okPembayaran && okTagihan;
    }

    /**
     * Tolak pembayaran.
     * Status pembayaran → 'ditolak', tagihan → 'ditolak'.
     * Anggota bisa mengajukan ulang.
     */
    public boolean tolak(int idPembayaran, int idTagihan,
                         int idAnggota, int idBendahara, String alasan) {
        boolean okPembayaran = pembayaranDAO.verifikasi(
            idPembayaran, "ditolak", alasan, idBendahara);

        boolean okTagihan = tagihanDAO.updateStatus(
            idTagihan, "ditolak",
            "Pembayaran ditolak: " + alasan);

        if (okPembayaran && okTagihan) {
            notifDAO.kirim(idAnggota,
                "Pembayaran Anda ditolak. Alasan: " + alasan
                + " - Silakan unggah ulang bukti pembayaran.",
                "ditolak", idPembayaran);
        }
        return okPembayaran && okTagihan;
    }
}
