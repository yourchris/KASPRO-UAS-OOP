package com.kaspro.controller;

import com.kaspro.dao.NotifikasiDAO;
import com.kaspro.dao.PeriodeDAO;
import com.kaspro.dao.TagihanDAO;
import com.kaspro.dao.UserDAO;
import com.kaspro.model.PeriodeKas;

import java.math.BigDecimal;

/**
 * Logika pengelolaan periode & tagihan oleh bendahara.
 */
public class TagihanController {

    private final PeriodeDAO    periodeDAO = new PeriodeDAO();
    private final TagihanDAO    tagihanDAO = new TagihanDAO();
    private final UserDAO       userDAO    = new UserDAO();
    private final NotifikasiDAO notifDAO   = new NotifikasiDAO();

    /** Hasil pembuatan periode. */
    public static class Hasil {
        public final boolean sukses;
        public final int     idPeriode;
        public final int     jumlahTagihan;
        public final String  pesan;
        public Hasil(boolean sukses, int idPeriode, int jumlahTagihan, String pesan) {
            this.sukses = sukses;
            this.idPeriode = idPeriode;
            this.jumlahTagihan = jumlahTagihan;
            this.pesan = pesan;
        }
    }

    /**
     * Membuat periode baru lalu otomatis membuat tagihan untuk semua anggota aktif,
     * menyiapkan baris rekap, dan mengirim notifikasi "tagihan baru".
     */
    public Hasil buatPeriode(PeriodeKas periode) {
        int jumlahAnggota = userDAO.countAnggotaAktif();
        if (jumlahAnggota == 0) {
            return new Hasil(false, -1, 0,
                "Belum ada anggota aktif. Tambahkan anggota terlebih dahulu.");
        }

        int idPeriode = periodeDAO.simpan(periode);
        if (idPeriode <= 0) {
            return new Hasil(false, -1, 0, "Gagal menyimpan periode.");
        }

        int jumlahTagihan = tagihanDAO.buatTagihanMassal(idPeriode, periode.getNominal());

        BigDecimal totalTagihan = periode.getNominal()
                .multiply(BigDecimal.valueOf(jumlahTagihan));
        periodeDAO.buatRekapAwal(idPeriode, totalTagihan, jumlahTagihan);

        notifDAO.kirimKeRole("anggota",
            "Tagihan baru: " + periode.getNamaPeriode()
            + " sebesar " + periode.getNominal().toBigInteger() + ". Silakan lakukan pembayaran.",
            "tagihan_baru", idPeriode);

        return new Hasil(true, idPeriode, jumlahTagihan,
            "Periode dibuat. " + jumlahTagihan + " tagihan diterbitkan untuk anggota.");
    }

    public boolean tutupPeriode(int idPeriode) {
        return periodeDAO.tutupPeriode(idPeriode);
    }
}
