package com.kaspro.controller;

import com.kaspro.dao.UserDAO;
import com.kaspro.model.User;

/**
 * Mengelola autentikasi dan sesi pengguna aktif (disimpan di memori).
 */
public class AuthController {

    private static User currentUser = null;
    private static final UserDAO userDAO = new UserDAO();

    /** Mencoba login. Bila berhasil, sesi diset. */
    public static boolean login(String username, String password) {
        User u = userDAO.login(username, password);
        if (u != null) {
            currentUser = u;
            return true;
        }
        return false;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static boolean isLoggedIn() {
        return currentUser != null;
    }

    public static void logout() {
        currentUser = null;
    }
}
