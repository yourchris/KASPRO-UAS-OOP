# KasPro — Sistem Manajemen Kas (NetBeans Java Swing / Ant)

Aplikasi desktop pengelolaan kas organisasi mahasiswa. Versi ini dibangun dengan
**Java Swing JFrame Form** (NetBeans GUI Builder) di atas proyek **Ant (Java Application)**,
dengan database **MySQL**.

Cakupan fitur (inti): **login → kelola periode → bayar → verifikasi**.

## Struktur singkat

```
KasProAnt/
├── build.xml                 # skrip Ant (NetBeans)
├── manifest.mf
├── nbproject/                # metadata proyek NetBeans
├── lib/                      # taruh JAR MySQL Connector/J di sini
├── database/db_kas.sql       # skrip pembuatan database + data contoh
└── src/
    ├── config.properties     # konfigurasi koneksi database
    └── com/kaspro/
        ├── Main.java         # titik masuk aplikasi
        ├── config/           # DBConnection
        ├── model/            # User, PeriodeKas, Tagihan, Pembayaran, Notifikasi
        ├── dao/              # akses database
        ├── controller/       # logika bisnis
        ├── util/             # utilitas (format, tanggal, file, password)
        └── view/             # JFrame Form (.java + .form)
            ├── FrmLogin
            ├── FrmMenu
            ├── FrmPeriode
            ├── FrmVerifikasi
            └── FrmBayar
```

## Cara menjalankan

### 1. Siapkan database
Jalankan skrip `database/db_kas.sql` di MySQL (misalnya lewat phpMyAdmin atau terminal):

```bash
mysql -u root -p < database/db_kas.sql
```

Skrip ini membuat database `db_kas`, seluruh tabel, trigger rekap otomatis,
akun contoh, serta satu periode + tagihan contoh agar tampilan tidak kosong.

### 2. Sesuaikan koneksi
Buka `src/config.properties`, sesuaikan `db.user` dan `db.password` dengan MySQL Anda.

### 3. Tambahkan driver MySQL
Aplikasi butuh **MySQL Connector/J**. Lihat `lib/BACA_DULU_taruh_jar_mysql_disini.txt`.
Singkatnya: unduh JAR-nya, lalu di NetBeans → klik kanan project → **Properties → Libraries →
Add JAR/Folder** → pilih file JAR tersebut.

### 4. Buka & jalankan di NetBeans
- **File → Open Project** → pilih folder `KasProAnt`.
- Saat pertama dibuka, NetBeans otomatis membuat `nbproject/build-impl.xml`
  (kalau muncul info "build script out of date", biarkan saja / klik OK).
- Tekan **F6** (Run). Aplikasi mulai dari form login.

## Akun default

| Username   | Password   | Peran     |
|------------|------------|-----------|
| admin      | admin123   | Admin     |
| bendahara  | kas12345   | Bendahara |
| budi       | budi123    | Anggota   |
| rina       | rina123    | Anggota   |
| deni       | deni123    | Anggota   |

## Alur singkat
- **Bendahara** login → menu → **Kelola Periode** (buat periode, otomatis menerbitkan
  tagihan untuk semua anggota aktif) atau **Verifikasi Pembayaran** (setujui/tolak).
- **Anggota** login → langsung ke form **Bayar**: pilih tagihan, isi metode, lampirkan
  bukti, kirim. Status berubah menjadi *menunggu verifikasi*.
- Saat bendahara menyetujui, trigger MySQL memperbarui rekap kas secara otomatis.

## Catatan
- File bukti pembayaran disalin ke folder `uploads/` (dibuat otomatis saat dipakai).
- Tampilan memakai Look & Feel **Nimbus** bawaan JDK — tanpa library UI tambahan.
- Versi ini sengaja diringkas ke fitur inti. Modul laporan/PDF dan dasbor tidak disertakan.
